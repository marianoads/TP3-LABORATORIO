#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "Employee.h"



int employee_setId(Employee* this,int id)
{

    int todoOk = 0;

    if( this != NULL && id > 0)
    {

        this->id = id;
        todoOk = 1;
    }

    return todoOk;
}


int employee_getId(Employee* this,int* id)
{

    int todoOk = 0;

    if( this != NULL && id != NULL )
    {

        *id = this->id;
        todoOk = 1;
    }
    return todoOk;
}


int employee_setNombre(Employee* this,char* nombre)
{

    int todoOk = 0;

    if( this != NULL && nombre != NULL && strlen(nombre) > 2)
    {

        strcpy(this->nombre, nombre);
        todoOk = 1;
    }

    return todoOk;

}
int employee_getNombre(Employee* this,char* nombre)
{

    int todoOk = 0;

    if( this != NULL && nombre != NULL )
    {

        strcpy(nombre, this->nombre);
        todoOk = 1;
    }

    return todoOk;

}

int employee_setHorasTrabajadas(Employee* this,int horasTrabajadas)
{

    int todoOk = 0;

    if( this != NULL && horasTrabajadas > 0)
    {

        this->horasTrabajadas = horasTrabajadas;
        todoOk = 1;
    }

    return todoOk;
}
int employee_getHorasTrabajadas(Employee* this,int* horasTrabajadas)
{

    int todoOk = 0;

    if( this != NULL && horasTrabajadas != NULL )
    {

        *horasTrabajadas = this->horasTrabajadas;
        todoOk = 1;
    }
    return todoOk;

}

int employee_setSueldo(Employee* this,int sueldo)
{

    int todoOk = 0;

    if( this != NULL && sueldo > 0)
    {

        this->sueldo = sueldo;
        todoOk = 1;
    }

    return todoOk;

}
int employee_getSueldo(Employee* this,int* sueldo)
{
    int todoOk = 0;

    if( this != NULL && sueldo != NULL )
    {

        *sueldo = this->sueldo;
        todoOk = 1;
    }
    return todoOk;
}

Employee* employee_new()
{

    Employee* this = (Employee*) malloc(sizeof(Employee));

    if( this != NULL)
    {
        this->id = 0;
        strcpy(this->nombre, "");
        this->horasTrabajadas = 0;
        this->sueldo = 0;
    }

    return this;
}


Employee* employee_newParametros(char* idStr,char* nombreStr,char* horasTrabajadasStr, char* sueldoStr)
{

    Employee* this;

    if (idStr != NULL && nombreStr != NULL && horasTrabajadasStr != NULL && sueldoStr != NULL)
    {
        this  = employee_new();

        if( this != NULL)
        {

            if( !employee_setId(this, atoi(idStr))||

                    !employee_setNombre(this, nombreStr) ||

                    !employee_setHorasTrabajadas(this, atoi(horasTrabajadasStr)) ||

                    !employee_setSueldo(this, atoi(sueldoStr)))
            {
                free(this);
                this = NULL;
            }
        }
    }

    return this;
}



void mostrarEmpleado(Employee* emp)
{
    if(emp != NULL)
    {
        printf("%d  %s  %d  %d\n", emp->id, emp->nombre, emp->horasTrabajadas, emp->sueldo);
    }
}


int ordenarXSueldo( void* emp1, void* emp2)
{

    int retorno = 0;
    Employee* p1;
    Employee* p2;

    if( emp1 != NULL && emp2 != NULL)
    {

        p1 = (Employee*) emp1;
        p2 = (Employee*) emp2;

        if( p1->sueldo > p2-> sueldo)
        {
            retorno = 1;
        }
        else if( p1->sueldo < p2-> sueldo)
        {
            retorno = -1;
        }
        else
        {
            retorno = 0;
        }

    }

    return retorno;
}

int ordenarXId( void* emp1, void* emp2)
{

    int retorno = 0;
    Employee* p1;
    Employee* p2;

    if( emp1 != NULL && emp2 != NULL)
    {

        p1 = (Employee*) emp1;
        p2 = (Employee*) emp2;

        if( p1->id > p2-> id)
        {
            retorno = 1;
        }
        else if( p1->id < p2->id)
        {
            retorno = -1;
        }
        else
        {
            retorno = 0;
        }

    }

    return retorno;
}

int ordenarXHoras( void* emp1, void* emp2)
{

    int retorno = 0;
    Employee* p1;
    Employee* p2;

    if( emp1 != NULL && emp2 != NULL)
    {

        p1 = (Employee*) emp1;
        p2 = (Employee*) emp2;

        if( p1->horasTrabajadas > p2->horasTrabajadas)
        {
            retorno = 1;
        }
        else if( p1->horasTrabajadas < p2->horasTrabajadas)
        {
            retorno = -1;
        }
        else
        {
            retorno = 0;
        }

    }

    return retorno;
}

int Employee_showEmployees(Employee* pArrayListEmployee, int sizeList)
{
    Employee* pEmployee;

    int i;
    int retorno = 0;
    char auxNombre[1024];
    int auxId;
    int auxHorasTrabajadas;
    int auxSueldo;

    for(i=0; i<sizeList; i++)
    {
        pEmployee = ll_get(pArrayListEmployee, i);
        employee_getNombre(pEmployee, auxNombre);
        employee_getSueldo(pEmployee, &auxSueldo);
        employee_getId(pEmployee, &auxId);
        employee_getHorasTrabajadas(pEmployee, &auxHorasTrabajadas);

        printf("\n%d - %s - %d - %d", auxId, auxNombre, auxHorasTrabajadas, auxSueldo);
    }

    return retorno;
}

int ordenarXNombre( void* emp1, void* emp2)
{

    int retorno = 0;
    Employee* p1;
    Employee* p2;

    if( emp1 != NULL && emp2 != NULL)
    {

        p1 = (Employee*) emp1;
        p2 = (Employee*) emp2;

        if( strcmp(p1->nombre,p2->nombre) == 1)
        {
            retorno = 1;
        }
        else if( strcmp(p1->nombre,p2->nombre) == -1)
        {
            retorno = -1;
        }
        else
        {
            retorno = 0;
        }

    }

    return retorno;
}

void mostrarLos15MejoresPagos(Employee *pArrayListEmployee)
{

    ll_sort(pArrayListEmployee,ordenarXSueldo,0); ///Ordeno por sueldo, de manera descendente
    Employee_showEmployees(pArrayListEmployee, 15); ///Muestro los primeros 15 empleados

}

void mostrarPersonasQueSuperenLos30000(Employee *pArrayListEmployee,int tam)
{
    Employee* pEmpleado;

    for(int i=0; i<tam; i++)
    {
        pEmpleado=ll_get(pArrayListEmployee,i);
        if(pEmpleado->sueldo > 30000)
        {
            mostrarEmpleado(pEmpleado);
        }
    }


}

int asignarIdANuevoEmpleado(Employee *pArrayListEmployee){
    int max=0;
        Employee* p;
        for(int i=0; i<ll_len(pArrayListEmployee); i++)
        {
            p=ll_get(pArrayListEmployee,i);
            if(p->id > max)
            {
                max=p->id;
            }
        };
        return max;
}

void menuInformes(Employee *pArrayListEmployee)
{
    int option;
    system("cls");
    printf("** MENU INFORMES **\n\n1-Ordenar por horas trabajadas\n2-Ordenar por sueldo\n3-Ordenar por nombre\n4-Mostrar los 15 mejores pagos\n5-Mostrar los que superen los 30000\n\nElija opcion: ");
    scanf("%d",&option);
    switch(option)
    {
    case 1:
        ll_sort(pArrayListEmployee,ordenarXHoras,1);
        Employee_showEmployees(pArrayListEmployee,ll_len(pArrayListEmployee));
        break;

    case 2:
        ll_sort(pArrayListEmployee,ordenarXSueldo,1);
        Employee_showEmployees(pArrayListEmployee,ll_len(pArrayListEmployee));

        break;
    case 3:
        ll_sort(pArrayListEmployee,ordenarXNombre,1);
        Employee_showEmployees(pArrayListEmployee,ll_len(pArrayListEmployee));
        break;
    case 4:
        mostrarLos15MejoresPagos(pArrayListEmployee);
        break;
    case 5:
        mostrarPersonasQueSuperenLos30000(pArrayListEmployee,ll_len(pArrayListEmployee));
        break;
    case 6:
        break;
    default:
        break;
    };
}
