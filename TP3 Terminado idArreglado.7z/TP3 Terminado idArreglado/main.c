#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "Employee.h"

/****************************************************
    Menu:
     1. Cargar los datos de los empleados desde el archivo data.csv (modo texto).
     2. Cargar los datos de los empleados desde el archivo data.bin (modo binario).
     3. Alta de empleado
     4. Modificar datos de empleado
     5. Baja de empleado
     6. Listar empleados
     7. Ordenar empleados
     8. Guardar los datos de los empleados en el archivo data.csv (modo texto).
     9. Guardar los datos de los empleados en el archivo data.bin (modo binario).
    10. Salir
*****************************************************/


int main()
{
    int option=0;
    char seguir='s';

    LinkedList* listaEmpleados = ll_newLinkedList();



    while(seguir=='s'){
        printf("ABM EMPLEADOS\n\n");
    printf("1-Cargar los datos de los empleados desde el archivo data.csv (modo texto)\n");
    printf("2-Cargar los datos de los empleados desde el archivo data.bin (modo binario)\n");
    printf("3-Alta de empleado\n");
    printf("4-Modificar datos de empleado\n");
    printf("5-Baja de empleado\n");
    printf("6-Listar empleados\n");
    printf("7-Ordenar empleados\n");
    printf("8-Guardar los datos de los empleados en el archivo data.csv (modo texto)\n");
    printf("9-Guardar los datos de los empleados en el archivo data.bin (modo binario)\n");
    printf("10-Informes\n");
    printf("11-Salir\n\n");

    printf("Ingrese opcion : ");
    scanf("%d", &option);


        switch(option)
        {
        case 1:
            controller_loadFromText("./data.csv",listaEmpleados);

            break;
        case 2:
            controller_loadFromBinary("./data.bin",listaEmpleados);
            break;
        case 3:
            controller_addEmployee(listaEmpleados);
            break;
        case 4:
            controller_editEmployee(listaEmpleados);
            break;
        case 5:
            controller_removeEmployee(listaEmpleados);
            break;
        case 6:
            printf("\n\nOrdenado por Id\n\n");
            ll_sort(listaEmpleados,ordenarXId,1);
            controller_showEmployees(listaEmpleados,ll_len(listaEmpleados));

            //printf("\n\n\nOrdenado por horas\n\n");

            //ll_sort(listaEmpleados,ordenarXHoras,0);
            //ll_sort(listaEmpleados,ordenarXSueldo,0);
            /*printf("\n\n\nOrdenado por Nombre\n\n");
            ll_sort(listaEmpleados,ordenarXNombre,0);
            controller_showEmployees(listaEmpleados,ll_len(listaEmpleados));

            printf("\n\n\nLos 15 mejores pagos\n\n");
            mostrarLos15MejoresPagos(listaEmpleados);
            printf("\n\n\nPersonas que superen los 30000\n\n");
            mostrarPersonasQueSuperenLos30000(listaEmpleados,ll_len(listaEmpleados));*/
            break;
        case 7:
            controller_sortEmployee(listaEmpleados);
            break;
        case 8:
            controller_saveAsText("./data.csv", listaEmpleados);
            break;
        case 9:
            controller_saveAsBinary("./data.bin", listaEmpleados);
            break;

        case 10:
            menuInformes(listaEmpleados);
            break;
        case 11:
            seguir= 'n';
        default:
            printf("Ingrese opcion correcta 1-10\n");
        }
        getch();
        system("cls");
    }

    return 0;
}
